<?php


if(isset($_REQUEST['add'])){
$sub=$_REQUEST['sub'];
$details=$_REQUEST['details'];
$user=$_REQUEST['email'];

$sql="insert into notice values(null,'".$sub."','".$details."','".$user."',null)";
echo $sql;

}

else{

  echo"error";
}








 ?>
