<?php

include 'dhp.php';
if(isset($_REQUEST['save'])){
$name=$_REQUEST['name'];
$email=$_REQUEST['email'];
$password=$_REQUEST['password'];
$mob=$_REQUEST['mob'];
$gen=$_REQUEST['gen'];
$hobbie=$_REQUEST['hob'];
$img=$_REQUEST['img'];
$dob=$_REQUEST['dob'];


$sql="insert into user values(null,'".$name."','".$email."','".$password."','".$mob."','".$gen."','".$hobbie."','".$img."','".$dob."')";
$result=mysqli_query($conn,$sql);
if($result){
   header('Location:registration.php?msg=<h2>Account is created!!</h2>');


}
else{

  header('Location:registration.php?msg=<h2>Account is not created!!</h2>');

}
}

else{

echo"error";

}










 ?>
