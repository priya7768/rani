
<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="css/bootstrap.css"/>
    <script src="js/jquery_library.js"></script>
<script src="js/bootstrap.min.js"></script>
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col-lg-4">
        </div>
<div class="col-lg-4">
    <h2>Add New Notice</h2><br><br>
    <form class="" action="notice_handler.php" method="post">
ENTER SUBJECT:<br><input type="text" name="sub"placeholder="subject"><br><br>
ENTER  DETAILS:<br><textarea name="details"></textarea><br><br>
SELECT USER: <input type="text" name="email"><br><br>

    <input type="submit" value="Add New Notice" name="add" class="btn btn-success"/>
    		<input type="reset" class="btn btn-success"/>

    </form>

</div>
<div class="col-lg-4">
</div>
</div>

    </div>

  </body>
</html>
